extends Control

@onready var map_buttons   = $VBoxContainer/MapSelect
@onready var diff_grid     = $VBoxContainer/DifficultyGrid
@onready var start_btn     = $VBoxContainer/StartBtn
@onready var speed_btn: Button  = $SpeedBoostButton
@onready var tp_btn: Button     = $TeleportEnemiesButton

func _ready() -> void:
	diff_grid.visible = false
	start_btn.disabled = true

	# Map thumbnails
	for btn in map_buttons.get_children():
		btn.pressed.connect(_on_map_chosen.bind(btn))

	# Difficulty buttons (1‒7)
	for i in range(1, 8):
		var diff_btn = diff_grid.get_node("Button%s" % i)
		diff_btn.pressed.connect(_on_difficulty_selected.bind(i))

	speed_btn.pressed.connect(_on_speed_boost_pressed)
	tp_btn.pressed.connect(_on_teleport_pressed)

	_update_buttons(Global.selected_powerup_effect)
	Global.powerup_effect_changed.connect(_update_buttons)

func _on_map_chosen(btn: TextureButton) -> void:
	var scene_path : String = btn.get_meta("scene_path")
	Global.chosen_map_scene = load(scene_path) as PackedScene
	diff_grid.visible = true       # now show the difficulties

func _on_difficulty_selected(level: int) -> void:
	Global.difficulty_level  = level
	Global.difficulty_config = Global.difficulty_settings[level]
	start_btn.disabled = false

	LSL.send_mark("rest", {"level": level})

func _on_StartBtn_pressed() -> void:
	var scene_path := Global.chosen_map_scene.resource_path if Global.chosen_map_scene != null else ""
	# stream "start" BEFORE scene switch
	LSL.send_mark("start", {
		"level": Global.difficulty_level,
		"scene": scene_path
	})

	Global.game_started.emit()
	get_tree().change_scene_to_packed(Global.chosen_map_scene)


func _on_start_btn_pressed() -> void:
	pass # Replace with function body.

func _on_speed_boost_pressed() -> void:
	Global.set_selected_powerup_effect(Global.PowerUpEffect.SPEED_BOOST)

func _on_teleport_pressed() -> void:
	Global.set_selected_powerup_effect(Global.PowerUpEffect.TELEPORT_ENEMIES)

func _update_buttons(effect: int) -> void:
	speed_btn.disabled = (effect == Global.PowerUpEffect.SPEED_BOOST)
	tp_btn.disabled    = (effect == Global.PowerUpEffect.TELEPORT_ENEMIES)

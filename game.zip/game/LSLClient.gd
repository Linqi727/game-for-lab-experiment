# LSLClient.gd (Godot 4.x, GDScript 2.0)
extends Node
class_name LSLClient

var _ws := WebSocketPeer.new()
var _url: String = "ws://127.0.0.1:8765" # change to hub IP if remote
var _app: String = "godot_game"
var _task: String = "demo"
var _connected := false
var _reconnect_wait := 1.0
var _queue: Array[String] = []

func _ready() -> void:
	set_process(true)
	_connect_ws()

func configure(url: String, app: String = "godot_game", task: String = "demo") -> void:
	_url = url
	_app = app
	_task = task

func _connect_ws() -> void:
	var err := _ws.connect_to_url(_url)
	if err != OK:
		_connected = false
		_schedule_reconnect()
		return

func _process(_delta: float) -> void:
	_ws.poll()
	var state := _ws.get_ready_state()
	if state == WebSocketPeer.STATE_OPEN:
		if not _connected:
			_connected = true
			_flush_queue()
		_drain_incoming() # keep socket healthy
	elif state == WebSocketPeer.STATE_CLOSED:
		if _connected:
			_connected = false
		_schedule_reconnect()

func _drain_incoming() -> void:
	while _ws.get_available_packet_count() > 0:
		_ws.get_packet() # discard

func _schedule_reconnect() -> void:
	_reconnect_wait = minf(_reconnect_wait * 1.5, 5.0)
	get_tree().create_timer(_reconnect_wait).timeout.connect(func(): _connect_ws())

func _flush_queue() -> void:
	for m in _queue:
		_send_text(m)
	_queue.clear()
	_reconnect_wait = 1.0

func _send_text(m: String) -> void:
	# Godot 4 usually has send_text(); fall back to binary if needed.
	if _ws.has_method("send_text"):
		_ws.send_text(m)
	else:
		_ws.send(m.to_utf8_buffer())

func send_mark(mark: String, extra: Dictionary = {}) -> void:
	var scene_path := (get_tree().current_scene.scene_file_path) if get_tree().current_scene != null else ""
	var payload := {
		"source": "godot",
		"app": _app,
		"task": _task,
		"scene": scene_path,
		"ts": int(Time.get_unix_time_from_system() * 1000),
		"mark": mark
	}
	for k in extra.keys():
		payload[k] = extra[k]

	var msg := JSON.stringify(payload) # (or JSON.new().stringify(payload) if you prefer)
	if _ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
		_send_text(msg)
	else:
		_queue.append(msg)

extends Area2D
class_name PowerUp

@export var duration_sec: float = 5.0        # used for speed boost
@export var speed_multiplier: float = 1.5    # used for speed boost
@export_file("*.ogg","*.wav") var pickup_sfx: String = ""  # optional

var _was_picked: bool = false
@onready var _shape: CollisionShape2D = $CollisionShape2D

func _ready() -> void:
	add_to_group("checkpoint_pickable")
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if _was_picked: return
	if not body.is_in_group("player"): return

	_was_picked = true
	hide()
	if _shape:
		_shape.call_deferred("set_disabled", true)

	# play SFX (optional)
	if pickup_sfx != "" and FileAccess.file_exists(pickup_sfx):
		AudioManager.play_sound_file(pickup_sfx, AudioManager.TrackTypes.PICKUPS)

	# trigger effect immediately
	var player := body as Player
	Global.apply_powerup_effect(player, duration_sec, speed_multiplier)
	# NOTE: do NOT queue_free; we keep the node for checkpoint restore

# --- checkpoint support ---
func serialize_state() -> Dictionary:
	return {
		"path": get_path(),
		"picked_up": _was_picked,
	}

func deserialize_state(state: Dictionary) -> void:
	_was_picked = state.get("picked_up", false)
	if _was_picked:
		hide()
		if _shape:
			_shape.disabled = true
	else:
		show()
		if _shape:
			_shape.disabled = false

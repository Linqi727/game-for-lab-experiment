extends Node2D
func _draw(): draw_circle(Vector2.ZERO, 5.0, Color(1, 0, 1))
func _process(_d): queue_redraw()

extends Node
#class_name AudioManager

const GAME_READY_STREAM: AudioStream = preload("res://assets/audio/game_ready.wav")
const LEVEL_CLEARED_STREAM: AudioStream = preload("res://assets/audio/success.wav")

@onready var music_player: AudioStreamPlayer  = $Music
@onready var pickups_player: AudioStreamPlayer = $Pickups
@onready var enemies_player: AudioStreamPlayer = $Enemies

# --- NEW: make sure the 3 players exist under this autoload ---
func _ensure_players() -> void:
	if music_player == null or !is_instance_valid(music_player):
		if has_node("Music"):
			music_player = $Music
		else:
			music_player = AudioStreamPlayer.new()
			music_player.name = "Music"
			add_child(music_player)

	if pickups_player == null or !is_instance_valid(pickups_player):
		if has_node("Pickups"):
			pickups_player = $Pickups
		else:
			pickups_player = AudioStreamPlayer.new()
			pickups_player.name = "Pickups"
			add_child(pickups_player)

	if enemies_player == null or !is_instance_valid(enemies_player):
		if has_node("Enemies"):
			enemies_player = $Enemies
		else:
			enemies_player = AudioStreamPlayer.new()
			enemies_player.name = "Enemies"
			add_child(enemies_player)

func _initialize_asserts() -> void:
	var stream_list: Array[AudioStream] = [GAME_READY_STREAM]
	for stream in stream_list:
		assert(stream != null)

func start() -> void:
	_ensure_players()
	stop_all_tracks()
	music_player.stream = GAME_READY_STREAM
	# connect one-shot callback instead of await (avoids get_tree() null race)
	if not music_player.finished.is_connected(_on_ready_finished):
		music_player.finished.connect(_on_ready_finished, CONNECT_ONE_SHOT)
	# defer play until next frame (ensures node is inside scene tree)
	call_deferred("_safe_play_music")

func _on_ready_finished() -> void:
	Global.game_started.emit()

func on_game_ready() -> void:
	start()

func on_level_cleared() -> void:
	_ensure_players()
	stop_all_tracks()
	music_player.stream = LEVEL_CLEARED_STREAM
	# just fire-and-forget the sfx; defer avoids “not inside tree”
	call_deferred("_safe_play_music")

# --- NEW: safe play helper that retries next frame if needed ---
func _safe_play_music() -> void:
	if music_player and music_player.is_inside_tree():
		music_player.play()
	else:
		# try again next frame in case we’re mid scene change
		call_deferred("_safe_play_music")

func _initialize_signals() -> void:
	if not Global.game_ready.is_connected(on_game_ready):
		Global.game_ready.connect(on_game_ready)
	if not Global.level_cleared.is_connected(on_level_cleared):
		Global.level_cleared.connect(on_level_cleared)

enum TrackTypes { MUSIC, PICKUPS, ENEMIES }

func play_sound_file(sound_file: String, track_type: TrackTypes) -> void:
	_ensure_players()
	match track_type:
		TrackTypes.MUSIC:
			music_player.stream = load(sound_file)
			if music_player.is_inside_tree(): music_player.play()
		TrackTypes.PICKUPS:
			pickups_player.stream = load(sound_file)
			if pickups_player.is_inside_tree(): pickups_player.play()
		TrackTypes.ENEMIES:
			enemies_player.stream = load(sound_file)
			if enemies_player.is_inside_tree(): enemies_player.play()
		_:
			printerr("(!) ERROR: In: " + name + ": Unhandled case in play_sound_file()!")

func stop_track(track_type: TrackTypes) -> void:
	match track_type:
		TrackTypes.MUSIC:   if music_player and music_player.is_inside_tree():   music_player.stop()
		TrackTypes.PICKUPS: if pickups_player and pickups_player.is_inside_tree(): pickups_player.stop()
		TrackTypes.ENEMIES: if enemies_player and enemies_player.is_inside_tree(): enemies_player.stop()
		_:
			printerr("(!) ERROR: In: " + name + ": Unhandled case in stop_track()!")

func stop_all_tracks() -> void:
	for node in get_children():
		if node is AudioStreamPlayer and node.is_inside_tree():
			node.stop()

func _ready() -> void:
	_ensure_players()
	_initialize_asserts()
	_initialize_signals()

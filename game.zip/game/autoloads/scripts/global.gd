extends Node

# ─── Signals ─────────────────────────────────────────────────────
signal lives_changed
signal score_changed
signal high_score_changed
signal player_died
signal player_finished_dying
signal game_ready
signal game_started
signal level_cleared
signal game_over
signal checkpoint_restored(snapshots: Array)
signal bonus_use_lock_changed(locked: bool)
signal difficulty_changed(level: int, cfg: Dictionary)
signal powerup_effect_changed(effect: int)
signal run_reset
@export var game_over_restart_delay_sec: float = 0.5
@export var restart_delay_sec: float = 5.0
@export var difficulty_level := 1

# ─── Lives & Score ────────────────────────────────────────────────
var initial_lives : int = 2
var lives : int = initial_lives
var max_lives : int = 5

var score : int = 0
var high_score : int = 0

var is_game_over: bool = false

@export var success_sound_file_path := "res://assets/audio/success.wav"
var point_to_gain_life_base_cap := 4500
var points_to_gain_life_cap := point_to_gain_life_base_cap

# ─── Game Mode & Difficulty ──────────────────────────────────────
enum GameMode { AUTONOMY_SATISFACTION, AUTONOMY_FRUSTRATION }
enum PowerUpEffect { SPEED_BOOST, TELEPORT_ENEMIES }
var game_mode := GameMode.AUTONOMY_SATISFACTION
var selected_powerup_effect: PowerUpEffect = PowerUpEffect.SPEED_BOOST

var difficulty_config := {}
var chosen_map_scene: PackedScene = null
var difficulty_settings := {
	1: {"ghosts":2, "speed_multiplier":1.3},
	2: {"ghosts":3, "speed_multiplier":1.5},
	3: {"ghosts":4, "speed_multiplier":1.8},
	4: {"ghosts":5, "speed_multiplier":2.0},
	5: {"ghosts":6, "speed_multiplier":2.0},
	6: {"ghosts":7, "speed_multiplier":2.5},
	7: {"ghosts":8, "speed_multiplier":2.5},
}

# ─── Checkpoint storage (if you use it) ─────────────────────────
var _checkpoint_enemy_states: Array[Dictionary] = []
var checkpoint_pending_spawn := false
var restoring_checkpoint: bool = false
var _checkpoint_global_state := {}
var _checkpoint_pickable_states: Array[Dictionary] = []
var _restored_once := false
var _pending_restart := false
var _restart_packed  : PackedScene = null
var _restart_path    : String      = ""
var _checkpoint_player_state: Dictionary = {}
var bonus_use_locked: bool = false

func _ready() -> void:
	_apply_difficulty(difficulty_level)
	# nothing here—other systems will hook up to our signals
	pass

func set_difficulty(level: int) -> void:
	level = clamp(level, 1, 7)
	if level == difficulty_level: return
	difficulty_level = level
	_apply_difficulty(level)

func _apply_difficulty(level: int) -> void:
	difficulty_config = difficulty_settings.get(level, difficulty_settings[1])
	print("[Global] difficulty =", level, " cfg=", difficulty_config)
	emit_signal("difficulty_changed", level, difficulty_config)

# ─── Setters / API ───────────────────────────────────────────────
func set_lives(v: int) -> void:
	if restoring_checkpoint and v <= 0:
		print("[Global] clamping lives during restore from", v, "to 1")
		v = 1

	lives = v
	print("[Global] set_lives ->", v)
	emit_signal("lives_changed")

# ─────────────────────────────────────────────────────────────────────────────
#  Lives / death / one-time checkpoint restore
# ─────────────────────────────────────────────────────────────────────────────
## ───────────────────────────────────────────────────────────────
##  Global.gd  –  drop-in replacement for the whole function
## ───────────────────────────────────────────────────────────────
func decrease_lives(amount: int = 1) -> void:
	# ------------------------------------------------------------
	# 0) compute new life total (do NOT broadcast yet)
	# ------------------------------------------------------------
	var remaining := lives - amount

	# ------------------------------------------------------------
	# 1) prune invalid BonusItem refs before we reason about them
	# ------------------------------------------------------------
	var player : Player = get_tree().get_first_node_in_group("player")
	if player:
		for i in range(player.power_inventory.size() - 1, -1, -1):
			var it = player.power_inventory[i]
			if it == null or not is_instance_valid(it) or not (it is BonusItem):
				player.power_inventory.remove_at(i)

	# ------------------------------------------------------------
	# 2) decide restore BEFORE setting lives (prevents game_over)
	# ------------------------------------------------------------
	var has_powerups : bool = player and player.power_inventory.size() > 0
	var in_sat_mode  : bool = (game_mode == GameMode.AUTONOMY_SATISFACTION)
	var can_restore  : bool = (remaining <= 0) and in_sat_mode and not _restored_once and has_powerups

	if can_restore:
		restoring_checkpoint = true
		# (a) consume ONE valid BonusItem
		var bi : BonusItem = player.power_inventory.pop_front()
		if bi and is_instance_valid(bi):
			bi.consume_for_restore()

		# (b) queue the restart – no lives signal this frame
		_restored_once = true
		checkpoint_pending_spawn = true
		print(">> [Global] decrease_lives: scheduling checkpoint restore")
		call_deferred("_restore_checkpoint_and_restart")
		return

	# ------------------------------------------------------------
	# 3) normal path: update lives and continue as before
	# ------------------------------------------------------------
	set_lives(remaining)
	if remaining == 1 and game_mode == GameMode.AUTONOMY_SATISFACTION:
		_save_checkpoint()
		print(">> saved lives=", _checkpoint_global_state["lives"],
		  " score=", _checkpoint_global_state["score"])
		chosen_map_scene = load(get_tree().current_scene.scene_file_path)

	# still have lives → normal death
	if remaining > 0:
		emit_signal("player_died")
		return
	
	if restoring_checkpoint:
		print("[Global] suppressing game_over during restore")
		return
	# no restore & no lives → true game over
	is_game_over = true
	LSL.send_mark("game_over", {
		"score": score,
		"lives": lives
	})
	emit_signal("game_over")
	await get_tree().create_timer(game_over_restart_delay_sec).timeout
	call_deferred("_reset_and_reload_current_scene")
	print("[Global] game_over emitted   lives=", lives, " restoring=", restoring_checkpoint)

# ─────────────────────────────────────────────────────────────────────────────
#  Helper: strip invalid entries & consume exactly one bonus
# ─────────────────────────────────────────────────────────────────────────────
func _consume_bonus_for_restore(player: Player) -> bool:
	if player == null:
		return false

	# prune null / freed refs first
	for i in range(player.power_inventory.size() - 1, -1, -1):
		var it = player.power_inventory[i]
		if it == null or not is_instance_valid(it):
			player.power_inventory.remove_at(i)

	if player.power_inventory.is_empty():
		return false      # nothing to pay with

	var bi: BonusItem = player.power_inventory.pop_front()
	bi.consume_for_restore()               # hides + queues free
	return true


func increase_lives(amount: int = 1) -> void:
	set_lives(min(lives + amount, max_lives))

func set_score(v: int) -> void:
	score = v
	emit_signal("score_changed")
	if score >= points_to_gain_life_cap:
		increase_lives()
		points_to_gain_life_cap += point_to_gain_life_base_cap
		AudioManager.play_sound_file(success_sound_file_path, AudioManager.TrackTypes.MUSIC)
	if score > high_score:
		set_high_score(score)

func increase_score(v: int) -> void:
	set_score(score + v)

func set_high_score(v: int) -> void:
	high_score = v
	emit_signal("high_score_changed")

# ─── (Optional) checkpoint helpers ──────────────────────────────
func _enemy_kind_from_ai(ai: Node) -> String:
	var cls = ai.get_class().to_lower()
	if "assassin" in cls:   return "assassin"
	if "bourrin" in cls:    return "bourrin"
	if "chelou" in cls:     return "chelou"
	if "cornichon" in cls:  return "cornichon"
	return "assassin"

func _save_checkpoint() -> void:
	_checkpoint_global_state = {
		"lives": lives,
		"score": score,
		"points_to_gain_life_cap": points_to_gain_life_cap
	}

	_checkpoint_enemy_states.clear()
	for node in get_tree().get_nodes_in_group("checkpoint_serializable"):
		if node is Enemy and node.has_method("serialize_state"):
			_checkpoint_enemy_states.append(node.serialize_state())

	_checkpoint_pickable_states.clear()
	for node in get_tree().get_nodes_in_group("checkpoint_pickable"):
		_checkpoint_pickable_states.append(node.serialize_state())
	
	var player = get_tree().get_first_node_in_group("player") as Player
	if player:
		_checkpoint_player_state = player.serialize_state()
		print("✔ checkpoint saved; player at ", _checkpoint_player_state["pos"])

func _restore_checkpoint_and_restart() -> void:
	var scene_path := get_tree().current_scene.scene_file_path if get_tree().current_scene != null else ""
	LSL.send_mark("restore & restart last life", {
		"lives": lives,
		"score": score,
		"scene": scene_path
	})

	print(">> RESTORE STEP 1: entering")
	# mark that we're restoring
	restoring_checkpoint = true
	is_game_over = false
	print(">> RESTORE STEP 2: about to reload scene")
	# 1) load the saved level scene
	var err = get_tree().change_scene_to_packed(chosen_map_scene)
	print(">> RESTORE STEP 2a: change_scene returned ", err)

	# 2) wait one frame so current_scene isn't null
	await get_tree().create_timer(0.0).timeout
	print(">> RESTORE STEP 3: scene is now ", get_tree().current_scene)
	
	var root = get_tree().current_scene
	if root and root.get_node_or_null("PauseMenuUI") == null:
		var pause_scene := preload("res://scenes/ui/pause_menu_ui.tscn")
		var pause_ui := pause_scene.instantiate()
		root.add_child(pause_ui)
	if not root:
		printerr("!!! No current_scene after reload!")
		return

	print(">> RESTORE STEP 4: restoring player")
	var player = get_tree().get_first_node_in_group("player") as Player
	if player and _checkpoint_player_state.size() > 0:
		player.deserialize_state(_checkpoint_player_state)
		print("✔ player restored to ", player.global_position)
	else:
		print(">> RESTORE STEP 4a: no player or no snapshot")

	print(">> RESTORE STEP 5: restoring globals")
	# 3) restore global values through the setters so signals fire
	set_lives(_checkpoint_global_state["lives"])
	set_score(_checkpoint_global_state["score"])
	points_to_gain_life_cap = _checkpoint_global_state["points_to_gain_life_cap"]
	print(">> RESTORE STEP 5a: lives=", lives, " score=", score)
	print(">> RESTORE STEP 6: emitting checkpoint_restored")

	# 4) emit exactly one 'checkpoint_restored' with your enemy data
	emit_signal("checkpoint_restored", _checkpoint_enemy_states)

	# 5) let SharedEnemyAI know to spawn from snapshots
	emit_signal("game_ready")

	print(">> RESTORE STEP 7: spawning enemies")
	# 6) small delay then kick off AI / timers
	await get_tree().create_timer(1.0).timeout
	emit_signal("game_started")

	# 7) restore every pickable (pellet / bonus) that implements deserialize_state()
	print(">> RESTORE STEP 8: restoring pickables")
	for st in _checkpoint_pickable_states:
		var pth: String = st.get("path", "")
		if pth == "":
			continue
		var node := root.get_node_or_null(pth)
		if node and node.has_method("deserialize_state"):
			node.deserialize_state(st)
			print("     – restored pickable", node)
		else:
			print("     – pickable missing or wrong type")

	print(">> RESTORE STEP 8a: recalculating pellet counters")
	var pellets = get_tree().get_first_node_in_group("pellets") as Pellets
	if pellets and root:
		var total_left: int = 0
		var normal_left: int = 0
		var power_left: int = 0

		var normal: Node = root.get_node_or_null("Pickables/Pellets/Normal")
		if normal:
			for p in normal.get_children():
				if p and p.has_method("serialize_state"):
					var sd: Dictionary = p.serialize_state()
					var picked_up: bool = sd.get("picked_up", false)
					if not picked_up:
						total_left += 1
						normal_left += 1

		var power: Node = root.get_node_or_null("Pickables/Pellets/Power")
		if power:
			for p in power.get_children():
				if p and p.has_method("serialize_state"):
					var sd: Dictionary = p.serialize_state()
					var picked_up: bool = sd.get("picked_up", false)
					if not picked_up:
						total_left += 1
						power_left += 1

		pellets.remaining_pellets_count        = total_left
		pellets.remaining_normal_pellets_count = normal_left
		pellets.remaining_power_pellets_count  = power_left

		print("    → pellets left:", total_left,
		  "(normal:", normal_left, "power:", power_left, ")")
	else:
		printerr(">> Couldn't find Pellets node to recalc counts!")

	print(">> RESTORE STEP 9: finished restore")
	restoring_checkpoint = false
	_checkpoint_player_state.clear()
	_set_bonus_use_lock(true)



func _emit_checkpoint_restored(snaps: Array[Dictionary]) -> void:
	emit_signal("checkpoint_restored", _checkpoint_enemy_states.duplicate())
	emit_signal("game_ready")
	call_deferred("_start_after_restore")

func _start_after_restore() -> void:
	await get_tree().create_timer(0.5).timeout
	emit_signal("game_started")

func queue_scene_restart(packed: PackedScene, path: String) -> void:
	if _pending_restart:
		return
	_pending_restart  = true
	_restart_packed   = packed
	_restart_path     = path
	# Call _do_scene_restart() on the NEXT frame, when it’s safe
	call_deferred("_do_scene_restart")

func _do_scene_restart() -> void:
	_set_bonus_use_lock(false)
	_pending_restart = false
	var st := get_tree()
	var err := OK
	if _restart_packed:
		err = st.change_scene_to_packed(_restart_packed)
	elif _restart_path != "":
		err = st.change_scene_to_file(_restart_path)
	else:
		# Last-chance fallback
		if st.current_scene and st.current_scene.scene_file_path != "":
			err = st.change_scene_to_file(st.current_scene.scene_file_path)

	if err != OK:
		push_warning("Scene reload failed (err %d)" % err)

func _set_bonus_use_lock(v: bool) -> void:
	if bonus_use_locked == v: return
	bonus_use_locked = v
	emit_signal("bonus_use_lock_changed", v)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		var scene_path := get_tree().current_scene.scene_file_path if get_tree().current_scene != null else ""
		LSL.send_mark("end", {"scene": scene_path})
		# optional: actually quit here if this is in a script that doesn't already quit
		# get_tree().quit()

func set_selected_powerup_effect(effect: PowerUpEffect) -> void:
	selected_powerup_effect = effect
	emit_signal("powerup_effect_changed", effect)
	print("[Global] powerup effect set to:", effect)

func apply_powerup_effect(player: Player, duration_sec: float, speed_mult: float) -> void:
	match selected_powerup_effect:
		PowerUpEffect.SPEED_BOOST:
			if player:
				player.apply_speed_boost(speed_mult, duration_sec)
		PowerUpEffect.TELEPORT_ENEMIES:
			teleport_all_enemies_to_spawn()

func teleport_all_enemies_to_spawn() -> void:
	for e in get_tree().get_nodes_in_group("enemies"):
		if e is Enemy:
			e.global_position = e.spawn_position
			# optional: snap their AI back to Scatter so they move sanely
			if e.enemy_ai:
				e.enemy_ai.set_state(EnemyAI.States.SCATTER)

func reset_run_state() -> void:
	# keep ONLY high_score
	is_game_over = false
	restoring_checkpoint = false
	_restored_once = false
	checkpoint_pending_spawn = false

	# reset core gameplay state
	points_to_gain_life_cap = point_to_gain_life_base_cap
	set_score(0)                        # emits score_changed → UI updates
	set_lives(initial_lives)            # emits lives_changed
	_set_bonus_use_lock(false)

	# wipe checkpoint caches
	_checkpoint_enemy_states.clear()
	_checkpoint_pickable_states.clear()
	_checkpoint_global_state.clear()
	_checkpoint_player_state.clear()

	emit_signal("run_reset")

func _reset_and_reload_current_scene() -> void:
	reset_run_state()

	var st := get_tree()
	var path := ""
	if st.current_scene and st.current_scene.scene_file_path != "":
		path = st.current_scene.scene_file_path

	if path != "":
		var err := st.change_scene_to_file(path)
		if err != OK:
			push_warning("Scene reload failed (err %d)" % err)

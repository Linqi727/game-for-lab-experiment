extends Panel
class_name ScoringUI

@onready var score_label: Label      = $HBoxContainer/ScoreLabel
@onready var high_score_label: Label = $HBoxContainer/HighScoreLabel

func _ready() -> void:
	# connect *to* the singleton’s signals by name, not via .score_changed
	Global.connect("score_changed", Callable(self, "on_score_changed"))
	Global.connect("high_score_changed", Callable(self, "on_high_score_changed"))
	Global.connect("game_over", Callable(self, "on_game_over"))

	# initialize display immediately
	on_score_changed()
	on_high_score_changed()

func on_score_changed() -> void:
	score_label.text = tr("Score:\n") + str(Global.score)

func on_high_score_changed() -> void:
	high_score_label.text = tr("High Score:\n") + str(Global.high_score)

func on_game_over() -> void:
	Global.set_score(0)

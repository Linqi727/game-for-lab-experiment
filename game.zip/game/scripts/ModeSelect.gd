extends Control

@onready var btn_sat = $Panel/VBoxContainer/BtnSatisfaction
@onready var btn_fru = $Panel/VBoxContainer/BtnFrustration

func _ready() -> void:
	btn_sat.pressed.connect(_on_mode_chosen.bind(Global.GameMode.AUTONOMY_SATISFACTION))
	btn_fru.pressed.connect(_on_mode_chosen.bind(Global.GameMode.AUTONOMY_FRUSTRATION))

func _on_mode_chosen(mode: int) -> void:
	Global.game_mode = mode
	get_tree().change_scene_to_file("res://difficulty_select.tscn")

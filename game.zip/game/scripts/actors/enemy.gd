@tool
extends Node2D
class_name Enemy
# keeps the editor happy when timers are added in‑tool
# Enemy.gd (top of file)
@export var enemy_ai: EnemyAI                # drag the AI child here in each enemy scene

# ── existing exports keep working ────────────────────────────
@export var spawn_point: Marker2D
@export var initial_direction := Vector2.DOWN
@export var spawn_position: Vector2 = Vector2.ZERO

@export var base_speed: float = 60
var chase_speed: float = base_speed
var scatter_speed: float = base_speed
var eaten_speed: float = base_speed * 2.0
var frightened_speed: float = base_speed / 2.0


#@onready var enemies_timers: Node = get_tree().root.get_node_or_null("Level/SharedEnemyAI/EnemiesTimers")
@onready var frightened_timer: Timer = get_tree().current_scene.get_node_or_null(
	"SharedEnemyAI/EnemiesTimers/FrightenedDurationTimer"
)
@onready var animation_tree        : AnimationTree        = $AnimationTree
@onready var anim_node_sm_playback : AnimationNodeStateMachinePlayback = animation_tree.get("parameters/playback")
@onready var colors_animation_player: AnimationPlayer     = $ColorsAnimationPlayer
const FRIGHTENED_FLASH_THRESHOLD := 2.0

signal died
# ── movement and AI vars (unchanged) ─────────────────────────
var direction : Vector2 = initial_direction
var speed     : float   = 0.0
var velocity  : Vector2 = Vector2.ZERO
var can_move  : bool    = true

# ── **freeze support** ───────────────────────────────────────
var is_frozen     : bool  = false
var _frozen_timer : Timer

func _resolve_enemy_ai() -> EnemyAI:
	if enemy_ai: return enemy_ai
	# auto‑detect first EnemyAI child if export not set
	for c in get_children():
		if c is EnemyAI:
			enemy_ai = c
			return enemy_ai
	return null

func _initialize_enemy() -> void:
	# Ensure visible + animation system active
	visible = true
	animation_tree.active = true
	if anim_node_sm_playback:
		anim_node_sm_playback.travel("move")

	# Disable color animation (could set alpha to 0)
	if colors_animation_player:
		colors_animation_player.stop()

	var s := get_node_or_null("Sprite2D") as Sprite2D
	if s:
		s.modulate = Color.WHITE
		s.z_as_relative = false
		s.z_index = 1000


func _ready() -> void:
	# 1) try the exported link
	if not enemy_ai:
		# 2) fallback: scan every child
		for c in get_children():
			if c is EnemyAI:
				enemy_ai = c
				break

	if not enemy_ai:
		push_error("%s: could not find any EnemyAI child — ghost will not move!" % name)
		return

	# now wire it up:
	enemy_ai.enemy = self
	if not enemy_ai.state_set.is_connected(_on_ai_state_set):
		enemy_ai.state_set.connect(_on_ai_state_set)

	var enemies_timers := get_tree().get_first_node_in_group("enemies_timers") as EnemiesTimers
	if enemies_timers:
		frightened_timer = enemies_timers.get_node("FrightenedDurationTimer")
	# … connect it here …
	else:
		push_warning("%s: EnemiesTimers not found; running without it." % name)

	if enemy_ai == null:
		push_error("%s: No EnemyAI found—this enemy won’t work!" % name)
		return

# Wire up
	enemy_ai.enemy = self
	_resolve_enemy_ai()  # now guaranteed to find it

	# Groups used by checkpoint save/restore
	add_to_group("enemies")
	add_to_group("checkpoint_serializable")

	# --- Minimal visual/animation init (important after checkpoint restore) ---
	var s := get_node_or_null("Sprite2D") as Sprite2D
	if s:
		s.visible = true
		s.modulate = Color.WHITE           # clear any alpha=0 left by animations
		s.z_as_relative = false            # draw above TileMap even with y-sort
		s.z_index = 1000
		s.region_enabled = false           # avoid blank atlas region after restore

	if animation_tree:
		animation_tree.active = true
	if anim_node_sm_playback:
		anim_node_sm_playback.travel("move")
	if colors_animation_player:
		colors_animation_player.stop()    # avoid invisible if previous anim set alpha 0
		colors_animation_player.play("normal")

	# --- Signals (guarded) ---
	if enemy_ai:
		if not enemy_ai.state_set.is_connected(_on_ai_state_set):
			enemy_ai.state_set.connect(_on_ai_state_set)
	else:
		push_error("%s: EnemyAI child not assigned/found." % name)

	if frightened_timer and not frightened_timer.timeout.is_connected(_on_frightened_timer_timeout):
		frightened_timer.timeout.connect(_on_frightened_timer_timeout)

	# --- Freeze helper timer ---
	_frozen_timer = Timer.new()
	_frozen_timer.one_shot = true
	_frozen_timer.timeout.connect(_on_unfreeze)
	add_child(_frozen_timer)

	# Apply visuals for the current AI state (fallback if AI missing)
	_apply_state_visual(enemy_ai.current_state if enemy_ai else EnemyAI.States.SCATTER)


# ── movement loop ────────────────────────────────────────────
func _physics_process(delta: float) -> void:
	if is_frozen or not can_move: return

	 # choose speed according to current AI state
	var speed_to_use := chase_speed
	if enemy_ai:
		match enemy_ai.current_state:
			EnemyAI.States.FRIGHTENED: speed_to_use = frightened_speed
			EnemyAI.States.SCATTER:    speed_to_use = scatter_speed
			EnemyAI.States.EATEN:      speed_to_use = eaten_speed
			EnemyAI.States.CHASE:      speed_to_use = chase_speed
	velocity = direction * speed_to_use
	# print(global_position)            # ← should spam changing numbers
	global_position += velocity * delta

	_update_frightened_flash()
		#  ✂ your existing animation code ✂
# ------------------------------------------------------------
# State → visual helpers
# ------------------------------------------------------------
func _on_ai_state_set(state: EnemyAI.States, _enemy: Enemy) -> void:
	_apply_state_visual(state)

func _apply_state_visual(state: EnemyAI.States) -> void:
	if not animation_tree: return

	match state:
		EnemyAI.States.EATEN:
			colors_animation_player.stop()
			if anim_node_sm_playback:
				anim_node_sm_playback.travel("going_home")
		EnemyAI.States.FRIGHTENED:
			if anim_node_sm_playback:
				anim_node_sm_playback.travel("move")
			colors_animation_player.play("frightened")
		_:
			if anim_node_sm_playback:
				anim_node_sm_playback.travel("move")
			colors_animation_player.play("normal")


# Called each frame while frightened to start flashing near the end
func _update_frightened_flash() -> void:
	if not enemy_ai or enemy_ai.current_state != EnemyAI.States.FRIGHTENED:
		return
	if not frightened_timer: return

	# Start flashing when only threshold seconds remain
	if frightened_timer.time_left <= FRIGHTENED_FLASH_THRESHOLD:
		if colors_animation_player.current_animation != "frightened_flash":
			colors_animation_player.play("frightened_flash")


# Reset to normal visuals when frightened ends and AI returns to background state
func _on_frightened_timer_timeout() -> void:
	# AI script will change the logical state; here we just ensure visuals revert
	if enemy_ai.current_state != EnemyAI.States.FRIGHTENED:
		_apply_state_visual(enemy_ai.current_state)

# ── freeze helpers ───────────────────────────────────────────
func apply_freeze(duration: float = 5.0) -> void:
	if is_frozen:
		_frozen_timer.start(duration)  # refresh
		return
	is_frozen = true
	can_move = false
	_frozen_timer.start(duration)

func _on_unfreeze() -> void:
	is_frozen = false
	can_move  = true

# ── snapshot for checkpoint ──────────────────────────────────
func serialize_state() -> Dictionary:
	return {
		"path"       : get_path(),
		"pos"        : global_position,
		"dir"        : direction,
		"is_frozen"  : is_frozen,
		"freeze_left": _frozen_timer.time_left
	}

func deserialize_state(d: Dictionary) -> void:
	global_position = d["pos"]
	direction       = d["dir"]
	if d["is_frozen"]:
		apply_freeze(d["freeze_left"])

func die() -> void:
	died.emit()
	is_frozen = false
	can_move = true

extends CharacterBody2D
class_name Player


@export var speed: float = 150.0
@export var spawn_point: Marker2D = null

@onready var spawn_position: Vector2 = spawn_point.global_position
@onready var animation_player: AnimationPlayer = $AnimationPlayer

var movement_input_vector: Vector2 = Vector2(0.0, 0.0)
var initial_direction: Vector2 = Vector2(1.0, 0.0)
var direction: Vector2 = self.initial_direction
var next_direction: Vector2 = direction
var power_inventory : Array[BonusItem] = []
var _base_speed: float
var _speed_boost_active: bool = false
var _speed_boost_timer: Timer


func _unhandled_key_input(_event: InputEvent) -> void:
	movement_input_vector = Vector2(0.0, 0.0)
	
	movement_input_vector.x = Input.get_axis("move_left", "move_right")
	if movement_input_vector.x != 0: return
	
	movement_input_vector.y = Input.get_axis("move_up", "move_down")


@onready var next_direction_detector: Node2D = $NextDirectionRotator/NextDirectionDetector

func can_go_in_next_direction() -> bool:
	for raycast in next_direction_detector.get_children():
		if raycast.is_colliding():
			return false
	return true


@onready var animation_tree: AnimationTree = $AnimationTree
@onready var anim_node_sm_playback: AnimationNodeStateMachinePlayback = animation_tree.get("parameters/playback")


@onready var hurt_box: HurtBox = $HurtBox

func enable() -> void:
	self.set_physics_process(true)
	self.set_process_unhandled_key_input(true)
	hurt_box.enable()


func disable() -> void:
	self.set_physics_process(false)
	self.set_process_unhandled_key_input(false)
	hurt_box.disable()


func die() -> void:
	disable()
	Global.decrease_lives()
	animation_tree.active = true
	anim_node_sm_playback.travel("die")
	_finish_death_after_delay()
	
func _finish_death_after_delay() -> void:
	await get_tree().create_timer(1.0).timeout   # length of your die animation
	Global.player_finished_dying.emit()


func on_game_ready() -> void:
	animation_tree.set("parameters/idle/blend_position", next_direction)
	anim_node_sm_playback.travel("idle")
	_base_speed = speed


func on_game_started() -> void:
	self.enable()


func on_level_cleared() -> void:
	self.disable()
	animation_tree.set("parameters/idle/blend_position", next_direction)
	anim_node_sm_playback.travel("idle")


func on_finished_dying() -> void:
	if Global.is_game_over: return
	global_position = spawn_position
	animation_tree.active = true


func _ready() -> void:
	add_to_group("checkpoint_serializable")
	add_to_group("player")
	assert(spawn_point != null)
	
	Global.game_ready.connect(on_game_ready)
	Global.game_started.connect(on_game_started)
	Global.level_cleared.connect(on_level_cleared)
	Global.player_finished_dying.connect(on_finished_dying)
	
	_base_speed = speed
	_speed_boost_timer = Timer.new()
	_speed_boost_timer.one_shot = true
	_speed_boost_timer.timeout.connect(_on_speed_boost_end)
	add_child(_speed_boost_timer)
	
	animation_tree.active = true
	self.disable()

	set_process_input(true)


@onready var next_direction_rotator: Node2D = $NextDirectionRotator

func _physics_process(_delta: float) -> void:
	if can_go_in_next_direction():
		direction = next_direction
	
	if movement_input_vector != Vector2(0.0, 0.0):
		next_direction = movement_input_vector

		if next_direction.x == -1.0:
			next_direction_rotator.set_rotation(deg_to_rad(180.0))
		elif next_direction.x == 1.0:
			next_direction_rotator.set_rotation(deg_to_rad(0.0))
		elif next_direction.y == -1.0:
			next_direction_rotator.set_rotation(deg_to_rad(-90.0))
		elif next_direction.y == 1.0:
			next_direction_rotator.set_rotation(deg_to_rad(90.0))
	
	if velocity != Vector2(0.0, 0.0):
		animation_tree.set("parameters/move/blend_position", velocity)
		anim_node_sm_playback.travel("move")
	else:
		animation_tree.set("parameters/idle/blend_position", next_direction)
		anim_node_sm_playback.travel("idle")
	
	self.velocity = direction * speed
	self.move_and_slide()
	
func _input(event: InputEvent) -> void:
	if event.is_action_pressed("use_power") \
	and not Global.bonus_use_locked \
	# and Global.game_mode == Global.GameMode.AUTONOMY_SATISFACTION \
	and power_inventory.size() > 0:
		var bi := _safe_pop_bonus()
		if bi:
			power_inventory.pop_front()
			bi.use_freeze()
		return

	if event.is_action_pressed("use_teleport") \
	and Global.game_mode == Global.GameMode.AUTONOMY_SATISFACTION \
	and not Global.bonus_use_locked \
	and power_inventory.size() > 0:
		var bi := _safe_pop_bonus()
		if bi:
			power_inventory.pop_front()
			bi.use_teleport(self)
		return

func _activate_next_power() -> void:
	# 1) prune any null or freed entries
	for i in range(power_inventory.size() - 1, -1, -1):
		var it = power_inventory[i]
		if it == null or not is_instance_valid(it) or not (it is BonusItem):
			power_inventory.remove_at(i)

	if power_inventory.is_empty():
		return

	# 2) grab the first valid item (guaranteed to be BonusItem now)
	var bi := power_inventory.pop_front() as BonusItem
	if not bi.is_inside_tree():
		return          # (shouldn’t happen, but cheap safeguard)

	# 3) use it
	bi.use_freeze()

# snapshot helpers
func serialize_state() -> Dictionary:
	var inv_paths: Array[NodePath] = []
	for item in power_inventory:
		if item and is_instance_valid(item):
			inv_paths.append(item.get_path())
	return {
		"pos"     : global_position,
		"dir"     : direction,
		"score"   : Global.score,
		"lives"   : Global.lives,
		"inv"     : inv_paths
	}

func deserialize_state(state: Dictionary) -> void:
	# --- 1.  Core player fields ---------------------------
	global_position = state.get("pos", global_position)
	direction       = state.get("dir", direction)
	Global.score    = state.get("score", Global.score)
	Global.lives    = state.get("lives", Global.lives)
	Global.set_score(state.get("score", Global.score))
	Global.set_lives(state.get("lives", Global.lives))


	# --- 2.  Rebuild the power-up inventory ---------------
	power_inventory.clear()

	var inv_data = state.get("inv", [])

	for p in state.get("inv", []):
		var n := get_node_or_null(p)
		if n and n is BonusItem:
			power_inventory.append(n)

func _safe_pop_bonus() -> BonusItem:
	# basic prune so we never return freed refs
	for i in range(power_inventory.size() - 1, -1, -1):
		var it = power_inventory[i]
		if it == null or not is_instance_valid(it) or not (it is BonusItem):
			power_inventory.remove_at(i)
	if power_inventory.is_empty():
		return null
	var bi: BonusItem = power_inventory[0]  # don't pop yet
	# double-check it's alive
	if not is_instance_valid(bi) or not bi.is_inside_tree():
		power_inventory.pop_front()
		return null
	return bi

func apply_speed_boost(mult: float = 1.5, duration_sec: float = 5.0) -> void:
	# Start/refresh a speed boost
	_speed_boost_active = true
	speed = _base_speed * mult
	_speed_boost_timer.start(duration_sec)

func _on_speed_boost_end() -> void:
	# Return to baseline when the boost ends
	_speed_boost_active = false
	speed = _base_speed

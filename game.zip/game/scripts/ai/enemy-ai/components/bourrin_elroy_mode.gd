extends Node
class_name BourrinElroyMode
## Handles “Elroy” speed‑up when few pellets remain.
## No more absolute node paths: everything is looked‑up via `owner`
## or small, one‑time group searches.

# ─────────────────────────────────────────────────────────────
#  Exported references
# ─────────────────────────────────────────────────────────────
@export var enemy_ai: EnemyAIBourrin = null          # must be set in the scene

# ─────────────────────────────────────────────────────────────
#  Cached node refs (filled in _ready)
# ─────────────────────────────────────────────────────────────
@onready var enemy: Enemy           = enemy_ai.enemy
@onready var enable_timer: Timer    = owner.get_node_or_null("EnableAITimer")
@onready var pellets_node: Pellets  = get_tree().get_first_node_in_group("pellets")
@onready var shared_enemy_ai: SharedEnemyAI = get_tree().get_root().get_node("Level/SharedEnemyAI") as SharedEnemyAI

# For backward‑compatibility you can still export percentages
@export var percentage_tier_1: float = 0.08
@export var percentage_tier_2: float = 0.04

# ─────────────────────────────────────────────────────────────
#  Internal state
# ─────────────────────────────────────────────────────────────
var remaining_pellets_count          : int   = 0
var tier_1_pellet_count_threshold    : int   = 0
var tier_2_pellet_count_threshold    : int   = 0


# ─────────────────────────────────────────────────────────────
#  Life‑cycle
# ─────────────────────────────────────────────────────────────
func _ready() -> void:
	# ---- validate mandatory refs ----
	if enemy_ai == null:
		push_error("BourrinElroyMode: `enemy_ai` export is not set!")
		queue_free()
		return

	if enable_timer == null:
		push_error("%s: EnableAITimer child not found" % owner.name)
		queue_free()
		return

	if pellets_node == null:
		push_error("BourrinElroyMode: Pellets node with group 'pellets' not found")
		queue_free()
		return

	# ---- connect signals ----
	enable_timer.timeout.connect(_on_enable_ai_timer_timeout)
	pellets_node.pellet_picked_up.connect(_on_pellet_picked_up)
	Global.player_died.connect(_on_player_died)

	# ---- initialise thresholds ----
	_init_tiers_and_remaining_pellets()


# ─────────────────────────────────────────────────────────────
#  Initial calculations
# ─────────────────────────────────────────────────────────────
func _init_tiers_and_remaining_pellets() -> void:
	remaining_pellets_count = pellets_node.remaining_pellets_count

	tier_1_pellet_count_threshold = round(remaining_pellets_count * percentage_tier_1)
	tier_2_pellet_count_threshold = round(remaining_pellets_count * percentage_tier_2)

	# edge cases
	if remaining_pellets_count <= 2:
		queue_free()
		return

	if tier_1_pellet_count_threshold == tier_2_pellet_count_threshold:
		tier_1_pellet_count_threshold = 2
		tier_2_pellet_count_threshold = 1


# ─────────────────────────────────────────────────────────────
#  Signal callbacks
# ─────────────────────────────────────────────────────────────
func _on_pellet_picked_up(_value: int) -> void:
	remaining_pellets_count = pellets_node.remaining_pellets_count
	_check_if_should_enable_elroy_mode()

func _on_player_died() -> void:
	_disable_elroy_mode()

func _on_enable_ai_timer_timeout() -> void:
	# Called when the ghost leaves its pen.
	_check_if_should_enable_elroy_mode()


# ─────────────────────────────────────────────────────────────
#  Elroy logic
# ─────────────────────────────────────────────────────────────
func _check_if_should_enable_elroy_mode() -> void:
	if remaining_pellets_count <= tier_2_pellet_count_threshold:
		_enable_elroy_mode(true)
	elif remaining_pellets_count <= tier_1_pellet_count_threshold:
		_enable_elroy_mode(false)

func _enable_elroy_mode(go_faster_than_player: bool) -> void:
	enemy_ai.elroy_mode_enabled = true

	var speed_mult := (1.2 if go_faster_than_player else 1.08)
	enemy_ai.enemy.chase_speed = enemy_ai.enemy.base_speed * speed_mult

	if enemy_ai.current_state == enemy_ai.States.CHASE:
		enemy.speed = enemy.base_speed * speed_mult
	elif enemy_ai.current_state == enemy_ai.States.SCATTER:
		enemy_ai.set_state(enemy_ai.States.CHASE)

func _disable_elroy_mode() -> void:
	enemy_ai.elroy_mode_enabled = false
	enemy.chase_speed = enemy.base_speed
	if shared_enemy_ai:
		enemy_ai.set_state(shared_enemy_ai.initial_ais_state)

extends Timer
class_name BonusItemActivationTimer

## Timer enabling a chosen BonusItem after a random amount of time
## when certain conditions are met.

@export var bonus_item : BonusItem
@export var min_rand_wait_time : int = 9
@export var max_rand_wait_time : int = 10
@export var pellet_cap_percentages_tiers : PackedFloat64Array = [0.70]

var remaining_activations_count : int
var remaining_pellets_percentage   : float
var remaining_pellets_cap          : int

@onready var pellets_node : Pellets = get_tree().root.get_node("Level/Pickables/Pellets")


func _ready() -> void:
	remaining_activations_count = pellet_cap_percentages_tiers.size()
	# Defer the rest of our setup until the scene is fully inited
	call_deferred("_late_ready")


func _late_ready() -> void:
	# 1) If no tiers, nothing to do
	if pellet_cap_percentages_tiers.size() == 0:
		bonus_item.queue_free()
		return

	_initialize_asserts()
	randomize()

	remaining_pellets_percentage = pellet_cap_percentages_tiers[ pellet_cap_percentages_tiers.size() - 1 ]
	remaining_pellets_cap = int(pellets_node.initial_pellets_count * remaining_pellets_percentage)

	# ─── pellet signal ─────────────────────────────
	var pellets_signal = pellets_node.pellet_picked_up
	var pellet_cb     = Callable(self, "on_pellet_picked_up")
	if not pellets_signal.is_connected(pellet_cb):
		pellets_signal.connect(pellet_cb)

	# ─── when the player picks it up ────────────────
	var bonus_sig = bonus_item.bonus_picked_up
	var bonus_cb  = Callable(self, "on_bonus_item_picked_up")
	if not bonus_sig.is_connected(bonus_cb):
		bonus_sig.connect(bonus_cb)

	# ─── on death / game‑over cleanup ──────────────
	var died_cb     = Callable(self, "on_player_died")
	var over_cb     = Callable(self, "on_game_over")
	# if not Global.player_died.is_connected(died_cb):
	# 	Global.player_died.connect(died_cb)
	if not Global.game_over.is_connected(over_cb):
		Global.game_over.connect(over_cb)

	# ─── the timer’s own timeout ───────────────────
	var to_cb       = Callable(self, "_on_timeout")
	if not timeout.is_connected(to_cb):
		timeout.connect(to_cb)


func on_pellet_picked_up(_value: int) -> void:
	print("[TIMER ", name, "] remaining=", pellets_node.remaining_pellets_count,
		  " cap=", remaining_pellets_cap,
		  " caps=", pellet_cap_percentages_tiers)
	# still above our next cap?
	if pellets_node.remaining_pellets_count > remaining_pellets_cap:
		return

	remaining_activations_count -= 1

	# start the timer & enable the BonusItem if it's not already running
	if is_stopped():
		var wait_time := float(randi_range(min_rand_wait_time, max_rand_wait_time))
		self.wait_time = wait_time
		start()
		bonus_item.enable()

	# remove that cap & compute the following one
	pellet_cap_percentages_tiers.remove_at(pellet_cap_percentages_tiers.size() - 1)
	if pellet_cap_percentages_tiers.size() == 0:
		# no more tiers → we won't fire again
		pellets_node.pellet_picked_up.disconnect(on_pellet_picked_up)
		return

	remaining_pellets_percentage = pellet_cap_percentages_tiers[ pellet_cap_percentages_tiers.size() - 1 ]
	remaining_pellets_cap        = int(pellets_node.initial_pellets_count * remaining_pellets_percentage)


func on_bonus_item_picked_up(_value: int, _tex: Texture2D) -> void:
	stop()
	# _check_queue_free()


func on_player_died() -> void:
	bonus_item.disable()
	_check_queue_free()
	stop()


func on_game_over() -> void:
	if Global.restoring_checkpoint:
		return
	bonus_item.queue_free()
	stop()


func _on_timeout() -> void:
	bonus_item.queue_free()
	# _check_queue_free()


func _check_queue_free() -> void:
	# once we've exhausted all activations *and* the item wasn't picked up
	if remaining_activations_count <= 0 and not bonus_item.stored and is_stopped():
		bonus_item.queue_free()


func _initialize_asserts() -> void:
	assert(bonus_item != null)
	assert(min_rand_wait_time < max_rand_wait_time)
	# ensure our percentages are strictly increasing in (0,1)
	var last_pct := 0.0
	for pct in pellet_cap_percentages_tiers:
		assert(pct > last_pct and pct > 0.0 and pct < 1.0)
		last_pct = pct

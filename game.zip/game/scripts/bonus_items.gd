# BonusItems.gd
extends Node
class_name BonusItems

signal item_picked_up(index: int, value: int, texture: Texture2D)
signal item_used(index: int)

const score_value_list     : PackedInt32Array  = [100,300,500,700,1000,2000,3000,5000]
const image_file_path_list : PackedStringArray = [
	"res://resources/atlas-textures/emerald_texture.tres",
	"res://resources/atlas-textures/book_texture.tres",
	"res://resources/atlas-textures/diamond_texture.tres",
	"res://resources/atlas-textures/cookie_texture.tres",
	"res://resources/atlas-textures/cookie_texture.tres",
	"res://resources/atlas-textures/cookie_texture.tres",
	"res://resources/atlas-textures/cookie_texture.tres",
	"res://resources/atlas-textures/cookie_texture.tres"
]
var caps := [
	[0.70],  # first bonus appears ≤70%
	[0.29],  # second ≤29%
	# …etc, one entry per child…
]

func _ready() -> void:
	assert(score_value_list.size() == image_file_path_list.size())
	assert(caps.size() == get_child_count())

	var pellets = get_tree().get_first_node_in_group("pellets")
	assert(pellets, "Pellets node not found in group 'pellets'!")

	for i in range(get_child_count()):
		var bonus = get_child(i) as BonusItem
		assert(bonus.has_method("setup"), "Child %d is not a BonusItem!" % i)

		# 1) initialize its score & texture
		bonus.setup(
			score_value_list[i],
			load(image_file_path_list[i]) as Texture2D
		)

		# 2) configure its activation timer
		var timer = bonus.get_node("BonusItemActivationTimer") as BonusItemActivationTimer
		timer.pellet_cap_percentages_tiers = caps[i]
		var pellet_cb = Callable(timer, "on_pellet_picked_up")
		if not pellets.pellet_picked_up.is_connected(pellet_cb):
			pellets.pellet_picked_up.connect(pellet_cb)
		#var cb = Callable(timer, "on_pellet_picked_up")
		#pellets.pellet_picked_up.connect(cb)

		# 3) **connect via inline lambdas** so we get the index first**
		bonus.bonus_picked_up.connect(func(value, texture):
			_on_child_bonus_picked_up(i, value, texture)
		)
		bonus.used.connect(func():
			_on_child_bonus_used(i)
		)

func _on_child_bonus_picked_up(index: int, value: int, texture: Texture2D) -> void:
	Global.increase_score(value)
	emit_signal("item_picked_up", index, value, texture)

func _on_child_bonus_used(index: int) -> void:
	emit_signal("item_used", index)

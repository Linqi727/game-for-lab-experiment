extends Area2D
class_name HurtBox

var enemy    : Enemy   = null
var enemy_ai : EnemyAI = null

func _ready() -> void:
	# Find Enemy ancestor (direct parent in your scene)
	var n := get_parent()
	while n and not (n is Enemy):
		n = n.get_parent()
	if n:
		enemy    = n
		enemy_ai = enemy.enemy_ai

	# Ensure shapes are enabled
	for c in get_children():
		if c is CollisionShape2D:
			c.disabled = false

func enable() -> void:
	for c in get_children():
		if c is CollisionShape2D:
			c.set_deferred("disabled", false)

func disable() -> void:
	for c in get_children():
		if c is CollisionShape2D:
			c.set_deferred("disabled", true)

func _on_area_entered(area: Area2D) -> void:
	# The area belongs to the player's detector; climb to the Player node
	var player := area.get_parent()
	if player == null or not player.is_in_group("player"):
		return

	if enemy_ai.current_state == EnemyAI.States.FRIGHTENED:
		enemy.die()                # player eats ghost
	elif enemy_ai.current_state != EnemyAI.States.EATEN:
		player.die()

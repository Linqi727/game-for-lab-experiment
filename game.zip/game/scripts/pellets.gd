extends Node
class_name Pellets

const DEBUG := true
func dbg(msg: String) -> void:
	if DEBUG:
		print("[Pellets] ", msg)

var initial_pellets_count: int = 0
var remaining_pellets_count: int = 0

var initial_normal_pellets_count: int = 0
var remaining_normal_pellets_count: int = 0

var initial_power_pellets_count: int = 0
var remaining_power_pellets_count: int = 0

var _restart_scheduled := false
var _restart_path: String = ""
var _restart_packed: PackedScene = null
var _shutting_down := false

func on_scene_tree_exited_by_pellet() -> void:
	if _shutting_down or !is_inside_tree():
		return
	# Fires when a pellet node exits the tree; schedule a clear check after tree updates
	dbg("pellet node exited; scheduling clear check")
	call_deferred("check_clear")

func _arm_and_schedule_reload() -> void:
	if _restart_scheduled:
		return
	_restart_scheduled = true
	_shutting_down     = true
	dbg("ALL CLEAR  →  emit level_cleared & queue restart")

	var scene_path := ""
	var scene_tree := Engine.get_main_loop() as SceneTree
	if scene_tree and scene_tree.current_scene and scene_tree.current_scene.scene_file_path != "":
		scene_path = scene_tree.current_scene.scene_file_path

	LSL.send_mark("level cleared", {"scene": scene_path})

	Global.level_cleared.emit()

	# Stop further tree-exit spam while the scene tears down
	for pellet_type_node in get_children():
		for pellet in pellet_type_node.get_children():
			if pellet.tree_exited.is_connected(on_scene_tree_exited_by_pellet):
				pellet.tree_exited.disconnect(on_scene_tree_exited_by_pellet)

	# Decide what we’ll ask Global to reload
	var packed : PackedScene = Global.chosen_map_scene          # may be null
	var path   : String      = ""                               # fallback

	if packed == null:
		var st := Engine.get_main_loop() as SceneTree
		if st and st.current_scene and st.current_scene.scene_file_path != "":
			path = st.current_scene.scene_file_path

	# 🔸 pass the two arguments that the utility expects
	Global.queue_scene_restart(packed, path)

func check_clear() -> void:
	if _restart_scheduled:
		dbg("check_clear: restart already queued; skipping")
		return

	# 1 – authoritative counter
	if remaining_pellets_count <= 0:
		dbg("check_clear: ALL CLEAR by counter")
		_arm_and_schedule_reload()
		return

	# 2 – fallback : every pellet-type child group is empty
	var empty_groups := 0
	for pellet_type_node in get_children():
		if pellet_type_node.get_child_count() == 0:
			empty_groups += 1

	dbg("check_clear fallback: empty=%d / total=%d" %
		[empty_groups, get_child_count()])

	if empty_groups == get_child_count():
		dbg("check_clear: ALL CLEAR by groups")
		_arm_and_schedule_reload()


func _exit_tree() -> void:
	_shutting_down = true

func _ready() -> void:
	add_to_group("checkpoint_serializable")
	var current_callable_on_pellet_picked_up: Callable = Callable()
	var callable_on_normal_pellet_picked_up: Callable = on_normal_pellet_picked_up
	var callable_on_power_pellet_picked_up: Callable = on_power_pellet_picked_up

	for pellet_type_group in get_children():
		if pellet_type_group.get_name() == "Normal":
			current_callable_on_pellet_picked_up = callable_on_normal_pellet_picked_up
			for normal_pellet in pellet_type_group.get_children():
				initial_normal_pellets_count += 1
		elif pellet_type_group.get_name() == "Power":
			current_callable_on_pellet_picked_up = callable_on_power_pellet_picked_up
			for power_pellet in pellet_type_group.get_children():
				initial_power_pellets_count += 1
		else:
			printerr("(!) ERROR! In: " + self.name + ": Unhandled pellet type!")

		for pellet in pellet_type_group.get_children():
			if not pellet.picked_up.is_connected(on_pellet_picked_up):
				pellet.picked_up.connect(on_pellet_picked_up)
			if not pellet.picked_up.is_connected(current_callable_on_pellet_picked_up):
				pellet.picked_up.connect(current_callable_on_pellet_picked_up)
			if not pellet.tree_exited.is_connected(on_scene_tree_exited_by_pellet):
				pellet.tree_exited.connect(on_scene_tree_exited_by_pellet)

			initial_pellets_count += 1

	assert(initial_pellets_count > 0)

	remaining_pellets_count = initial_pellets_count
	remaining_normal_pellets_count = initial_normal_pellets_count
	remaining_power_pellets_count = initial_power_pellets_count

	dbg("ready: total=%d (normal=%d, power=%d)" % [
		initial_pellets_count, initial_normal_pellets_count, initial_power_pellets_count
	])

signal pellet_picked_up(value: int)
signal normal_pellet_picked_up(value: int)
signal power_pellet_picked_up(value: int)

func on_pellet_picked_up(score_to_add: int) -> void:
	remaining_pellets_count -= 1
	Global.increase_score(score_to_add)
	pellet_picked_up.emit(score_to_add)
	dbg("pellet picked: +%d, remaining=%d" % [score_to_add, remaining_pellets_count])

	# When the last pellet is picked, immediately drive the restart path.
	if remaining_pellets_count <= 0:
		dbg("ALL pellets collected -> scheduling restart via check_clear()")
		check_clear()

func on_normal_pellet_picked_up(score_to_add: int) -> void:
	# (Optional) keep per-type counters accurate for debugging/analytics
	remaining_normal_pellets_count -= 1
	normal_pellet_picked_up.emit(score_to_add)

func on_power_pellet_picked_up(score_to_add: int) -> void:
	# (Optional) keep per-type counters accurate for debugging/analytics
	remaining_power_pellets_count -= 1
	power_pellet_picked_up.emit(score_to_add)

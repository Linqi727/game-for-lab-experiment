# BonusItem.gd
extends Pickable
class_name BonusItem

signal used
signal bonus_picked_up(value: int, texture: Texture2D)

@export var numbers_displayer_scene: PackedScene
const FREEZE_DURATION := 5.0

@export var spawn_sfx: AudioStream

@onready var sprite_2d          : Sprite2D         = $Sprite2D
@onready var collision_shape_2d : CollisionShape2D = $CollisionShape2D

var _spawn_player: AudioStreamPlayer2D
var stored: bool = false

func _ready() -> void:
	hide()
	collision_shape_2d.disabled = true
	add_to_group("checkpoint_pickable")
	body_entered.connect(Callable(self, "_on_body_entered"))

	_spawn_player = AudioStreamPlayer2D.new()
	_spawn_player.autoplay = false
	add_child(_spawn_player)

func setup(score: int, tex: Texture2D) -> void:
	score_value       = score
	sprite_2d.texture = tex

func enable() -> void:
	var was_inactive := not stored
	stored = true
	show()
	collision_shape_2d.call_deferred("set_disabled", false)

	if was_inactive and not Global.restoring_checkpoint and spawn_sfx:
		_spawn_player.stream = spawn_sfx
		_spawn_player.play()


func disable() -> void:
	stored = false
	hide()
	collision_shape_2d.call_deferred("set_disabled", true)

func _on_body_entered(body: Node) -> void:
	if not stored or not body.is_in_group("player"):
		return
	var player = body as Player
	player.power_inventory.append(self)
	bonus_picked_up.emit(score_value, sprite_2d.texture)
	stored = false
	hide()
	collision_shape_2d.call_deferred("set_disabled", true)

func use_freeze() -> void:
	if Global.bonus_use_locked:
		return
	for g in get_tree().get_nodes_in_group("enemies"):
		if g.has_method("apply_freeze"):
			g.apply_freeze(FREEZE_DURATION)
	used.emit()
	queue_free()

func use_teleport(player: Player) -> void:
	if Global.bonus_use_locked:
		return
	player.global_position = player.spawn_position
	used.emit()
	queue_free()

func consume_for_restore() -> void:
	stored = false
	disable()
	queue_free()

func serialize_state() -> Dictionary:
	return {
		"path"  : get_path(),
		"stored": stored,
	}

func deserialize_state(state: Dictionary) -> void:
	stored = state.get("stored", false)
	if stored:
		enable()
	else:
		disable()

extends Area2D
class_name Pickable

@export var score_value: int = 0
@export_file("*.ogg", "*.wav") var sound_file_path: String = ""

signal picked_up(value: int)

var _was_picked: bool = false

func _ready() -> void:
	assert(score_value > 0)
	assert(FileAccess.file_exists(sound_file_path))
	add_to_group("checkpoint_pickable")
	# connect body_entered → _on_body_entered
	body_entered.connect(Callable(self, "_on_body_entered"))

func _on_body_entered(body: Node) -> void:
	print("[BonusItem] body_entered with:", body)
	if not body.is_in_group("player"):
		return

	_was_picked =true
	call_deferred("hide")
	$CollisionShape2D.call_deferred("set_disabled", true)

	emit_signal("picked_up", score_value)
	AudioManager.play_sound_file(sound_file_path, AudioManager.TrackTypes.PICKUPS)

	# instead of queue_free(), defer it:
	# call_deferred("queue_free")

func serialize_state() -> Dictionary:
	return {
		"path"      : get_path(),
		"picked_up" : _was_picked,
	}

func deserialize_state(state: Dictionary) -> void:
	_was_picked = state.get("picked_up", false)
	if _was_picked:
		hide()
		$CollisionShape2D.disabled = true
	else:
		show()
		$CollisionShape2D.disabled = false

extends Node
class_name SharedEnemyAI

# ─── PackedScenes for each ghost type ───────────────────────────
@export var enemy_scene_assassin  : PackedScene
@export var enemy_scene_bourrin   : PackedScene
@export var enemy_scene_chelou    : PackedScene
@export var enemy_scene_cornichon : PackedScene

# ─── NODE REFERENCES ─────────────────────────────────────────────
@onready var tile_map        : TileMap       = get_tree().current_scene.get_node("TileMap")
@onready var enemies_parent  : Node          = get_tree().current_scene.get_node("Actors/Enemies")
@onready var pellets         : Pellets       = get_tree().get_first_node_in_group("pellets")
@onready var enemies_timers  : EnemiesTimers = $EnemiesTimers
@onready var scatter_timer   : Timer         = enemies_timers.get_node("ScatterDurationTimer")
@onready var chase_timer     : Timer         = enemies_timers.get_node("ChaseDurationTimer")
@onready var frightened_timer: Timer         = enemies_timers.get_node("FrightenedDurationTimer")

# ─── STATE ───────────────────────────────────────────────────────
var enemy_ai_list       : Array[EnemyAI]     = []
var walkable_tiles_list : PackedVector2Array = []

@export var initial_ais_state: EnemyAI.States = EnemyAI.States.SCATTER

# ─── LIFECYCLE ──────────────────────────────────────────────────
func _ready() -> void:
	# connect signals
	Global.game_started.connect(on_game_started)
	Global.checkpoint_restored.connect(_on_checkpoint_restored)
	frightened_timer.timeout.connect(_on_frightened_timer_timeout)

	# deferred spawn (so the tree is fully ready)
	call_deferred("_late_spawn_check")


# ─── DEFERRED SPAWN ENTRYPOINT ───────────────────────────────────
func _late_spawn_check() -> void:
	# 1) clear any pre‑placed ghosts (placeholders or leftovers)
	for old in enemies_parent.get_children():
		old.queue_free()
	enemy_ai_list.clear()

	# 2) choose snapshot vs. fresh difficulty
	if Global.checkpoint_pending_spawn and Global._checkpoint_enemy_states.size() > 0:
		print("[SharedEnemyAI] deferred → spawning from snapshots")
		spawn_enemies_from_snapshots(Global._checkpoint_enemy_states.duplicate())
		Global.checkpoint_pending_spawn = false
	else:
		print("[SharedEnemyAI] deferred → spawning for difficulty")
		spawn_enemies_for_difficulty()

	# 3) rebuild tile cache
	build_walkable_tiles_list()


func _on_checkpoint_restored(snapshots: Array[Dictionary]) -> void:
	# whenever Global emits checkpoint_restored, defer an immediate respawn
	call_deferred("spawn_enemies_from_snapshots", snapshots)


# ─── NORMAL DIFFICULTY SPAWN ────────────────────────────────────
func spawn_enemies_for_difficulty() -> void:
	# 1) gather config
	var cfg          = Global.difficulty_config
	var max_enemies  = int(cfg.get("ghosts", 0))
	var speed_mul    = float(cfg.get("speed_multiplier", 1.0))
	print("[SharedEnemyAI] → spawn_enemies_for_difficulty: max=", max_enemies, " speed_mul=", speed_mul)
	
	# 2) find spawn markers
	var level        = get_tree().current_scene
	var sp_root      = level.get_node_or_null("EnemiesSpawnPoints")
	if sp_root == null:
		printerr("[SharedEnemyAI] ⚠️ could not find 'EnemiesSpawnPoints' under ", level.name)
		return
	var markers      = sp_root.get_children()
	print("[SharedEnemyAI] → found ", markers.size(), " markers")
	if max_enemies <= 0:
		printerr("[SharedEnemyAI] ⚠️ max_enemies is zero; aborting spawn")
		return
	if markers.is_empty():
		printerr("[SharedEnemyAI] ⚠️ markers list is empty; check your scene tree!")
		return

	# 3) clear out old ghosts
	for old in enemies_parent.get_children():
		old.queue_free()
	enemy_ai_list.clear()

	# 4) actually spawn
	for i in range(max_enemies):
		var scenes = [
			enemy_scene_assassin,
			enemy_scene_bourrin,
			enemy_scene_chelou,
			enemy_scene_cornichon
		]
		var scene : PackedScene = scenes[i % scenes.size()]
		if not scene:
			printerr("[SharedEnemyAI] ⚠️ scene[", i, "] is null; skipping")
			continue
		var ghost : Enemy = scene.instantiate() as Enemy
		enemies_parent.add_child(ghost)

		# position it
		var m : Node2D = markers[i % markers.size()] as Node2D
		ghost.spawn_position  = m.global_position
		ghost.global_position = m.global_position

		# set speeds
		ghost.base_speed      *= speed_mul
		ghost.chase_speed     = ghost.base_speed
		ghost.scatter_speed   = ghost.base_speed
		ghost.eaten_speed     = ghost.base_speed * 2.0
		ghost.frightened_speed= ghost.base_speed / 2.0

		# hook up AI
		var ai := ghost.get_node("EnemyAI") as EnemyAI
		assert(ai, "Every Enemy scene must have an EnemyAI child named exactly 'EnemyAI'")
		ghost.enemy_ai = ai
		ai.enemy = ghost
		if not ai.state_set.is_connected(on_enemy_state_set):
			ai.state_set.connect(on_enemy_state_set)
			enemy_ai_list.append(ai)

		# force‑show everything and print its visibility
		ghost.show()
		var spr : Sprite2D = ghost.get_node_or_null("Sprite2D") as Sprite2D
		if spr:
			spr.show()


	# 5) final tally
	print("[SharedEnemyAI] spawn complete – child_count=", enemies_parent.get_child_count())


# ─── RESTORE FROM SNAPSHOTS ─────────────────────────────────────
func spawn_enemies_from_snapshots(snapshots: Array[Dictionary]) -> void:
	print("[SharedEnemyAI] spawn_enemies_from_snapshots:", snapshots.size())
	# clear out old
	for old in enemies_parent.get_children():
		old.queue_free()
	enemy_ai_list.clear()

	for snap in snapshots:
		if typeof(snap) != TYPE_DICTIONARY:
			push_warning("[SharedEnemyAI] spawn: skipping non‑dict: %s" % snap)
			continue

		var data := snap as Dictionary

		var kind:   String  = data.get("kind",  "assassin")
		var pos:    Vector2 = data.get("pos",   Vector2.ZERO)
		var dir:    Vector2 = data.get("dir",   Vector2.RIGHT)

		var scene: PackedScene
		match kind:
			"assassin":  scene = enemy_scene_assassin
			"bourrin":   scene = enemy_scene_bourrin
			"chelou":    scene = enemy_scene_chelou
			"cornichon": scene = enemy_scene_cornichon
			_:           scene = enemy_scene_assassin

		if not scene:
			push_warning("[SharedEnemyAI] ⚠️ no PackedScene for kind ‘%s’" % kind)
			continue

		var ghost = scene.instantiate() as Enemy
		enemies_parent.add_child(ghost)

		ghost.spawn_position  = pos
		ghost.global_position = pos
		ghost.direction       = dir

		# restore speeds
		var mult = float(Global.difficulty_config.get("speed_multiplier", 1.0))
		ghost.base_speed      *= mult
		ghost.chase_speed      = ghost.base_speed
		ghost.scatter_speed    = ghost.base_speed
		ghost.eaten_speed      = ghost.base_speed * 2.0
		ghost.frightened_speed = ghost.base_speed / 2.0

		# AI hookup
		var ai := ghost.get_node("EnemyAI") as EnemyAI
		assert(ai, "Every Enemy scene must have an EnemyAI child named exactly 'EnemyAI'")
		ghost.enemy_ai = ai
		ai.enemy = ghost
		if not ai.state_set.is_connected(on_enemy_state_set):
			ai.state_set.connect(on_enemy_state_set)
			enemy_ai_list.append(ai)

		ghost.show()
		if ghost is CanvasItem:
			ghost.z_as_relative = false
			ghost.z_index       = 1000

	# rebuild tile cache
	build_walkable_tiles_list()


# ─── WALKABLE TILES CACHE ───────────────────────────────────────
func build_walkable_tiles_list() -> void:
	walkable_tiles_list.clear()
	for cell in tile_map.get_used_cells(0):
		var data = tile_map.get_cell_tile_data(0, cell)
		if data and data.get_custom_data("walkable"):
			walkable_tiles_list.append(cell)
			print("Walkables:", walkable_tiles_list.size())


# ─── AI STATE CHANGES (score/combo) ────────────────────────────
func on_enemy_state_set(state: EnemyAI.States, _enemy: Enemy) -> void:
	# your combo / scoring logic here
	pass


# ─── GAME STARTED: reset AI & timers ───────────────────────────
func on_game_started() -> void:
	for ai in enemy_ai_list:
		ai.enable()
		ai.set_state(initial_ais_state)
	scatter_timer.start()


# ─── FRIGHTENED TIMER EXPIRES ─────────────────────────────────
func _on_frightened_timer_timeout() -> void:
	# reset any “combo” you might have
	pass

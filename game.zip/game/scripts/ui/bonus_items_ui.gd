# BonusItemsUI.gd
extends Panel
class_name BonusItemsUI

@onready var bonus_items        : BonusItems    = get_tree().root.get_node("Level/Pickables/BonusItems")
@onready var textures_container : HBoxContainer = $MarginContainer/HBoxContainer

var texture_rect_list : Array[TextureRect] = []

func _ready() -> void:
	# 1) Build one TextureRect per BonusItem child
	for i in range(bonus_items.get_child_count()):
		var slot = TextureRect.new()
		slot.expand_mode = TextureRect.EXPAND_FIT_WIDTH
		slot.hide()
		textures_container.add_child(slot)
		texture_rect_list.append(slot)

	# 2) Listen to the two unified signals on BonusItems
	bonus_items.item_picked_up.connect(Callable(self, "_on_bonus_item_picked_up"))
	bonus_items.item_used.connect(Callable(self, "_on_bonus_item_used"))

	_update_bonus_lock_visual(Global.bonus_use_locked)
	Global.bonus_use_lock_changed.connect(_update_bonus_lock_visual)

func _on_bonus_item_picked_up(index: int, value: int, texture: Texture2D) -> void:
	var slot = texture_rect_list[index]
	slot.texture = texture
	slot.show()

func _on_bonus_item_used(index: int) -> void:
	texture_rect_list[index].hide()

func _update_bonus_lock_visual(locked: bool) -> void:
	var c_disabled := Color(1, 1, 1, 0.35)
	var c_enabled  := Color(1, 1, 1, 1.0)
	for slot in texture_rect_list:
		slot.modulate = (c_disabled if locked else c_enabled)

extends Area2D
class_name WarpZone

@export var warp_destination_node: Node2D
var warp_destination_position: Vector2

func _ready() -> void:
	if warp_destination_node:
		warp_destination_position = warp_destination_node.global_position
	else:
		push_error("%s: warp_destination_node not assigned." % name)

func _on_body_entered(body: Player) -> void:
	if warp_destination_node:
		body.global_position = warp_destination_position
